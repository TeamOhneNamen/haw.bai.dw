package hello;

public class Artikel {

	int artikelNummer;
	String artName;
	String artGruppe;
	String gruppenName;
	
	public int getArtikelNummer() {
		return artikelNummer;
	}
	public String getArtName() {
		return artName;
	}
	public String getArtGruppe() {
		return artGruppe;
	}
	public String getGruppenName() {
		return gruppenName;
	}
	
	public Artikel(int artikelNummer, String artName, String artGruppe, String gruppenName) {
		
		this.artikelNummer = artikelNummer;
		this.artName = artName;
		this.artGruppe = artGruppe;
		this.gruppenName = gruppenName;
		
	}
	
}
