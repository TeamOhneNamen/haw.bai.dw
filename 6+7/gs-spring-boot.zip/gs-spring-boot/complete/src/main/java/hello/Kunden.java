package hello;

public class Kunden {

	int id;
	String nachname;
	String name;
	String strasse;
	String plz;
	String ort;

	
	public int getId() {
		return id;
	}


	public String getNachname() {
		return nachname;
	}


	public String getName() {
		return name;
	}


	public String getStrasse() {
		return strasse;
	}


	public String getPlz() {
		return plz;
	}


	public String getOrt() {
		return ort;
	}


	public Kunden(int id, String nachname, String name, String strasse, String plz, String ort) {
	
		this.id = id;
		this.nachname = nachname;
		this.name = name;
		this.strasse = strasse;
		this.plz = plz;
		this.ort = ort;
	
	}
	
}
