package hello;

import java.time.LocalDateTime;

public class Absatz {

	String filiale;
	LocalDateTime dateTime;
	int artikel;
	int anzahl;
	double preis;
	double umsatz;
	String verkaufer;
	int kundennummer;
	
	public String getFiliale() {
		return filiale;
	}
	public LocalDateTime getDateTime() {
		return dateTime;
	}
	public int getArtikel() {
		return artikel;
	}
	public int getAnzahl() {
		return anzahl;
	}
	public double getPreis() {
		return preis;
	}
	public double getUmsatz() {
		return umsatz;
	}
	public String getVerkaufer() {
		return verkaufer;
	}
	public int getKundennummer() {
		return kundennummer;
	}
	
	public Absatz(String filiale, LocalDateTime dateTime, int artikel, int anzahl, double preis, double umsatz, String verkaufer, int kundennummer) {
		this.anzahl = anzahl;
		this.artikel = artikel;
		this.dateTime = dateTime;
		this.filiale = filiale;
		this.kundennummer = kundennummer;
		this.preis = preis;
		this.umsatz = umsatz;
		this.verkaufer = verkaufer;
	}
	
}
