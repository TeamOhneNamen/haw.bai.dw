package hello;

/* Copyright (c) 2015, Oracle and/or its affiliates. All rights reserved.*/
/*
   DESCRIPTION    
   The code sample shows how to use the DataSource API to establish a connection
   to the Database. You can specify properties with "setConnectionProperties".
   This is the recommended way to create connections to the Database.

   Note that an instance of oracle.jdbc.pool.OracleDataSource doesn't provide
   any connection pooling. It's just a connection factory. A connection pool,
   such as Universal Connection Pool (UCP), can be configured to use an
   instance of oracle.jdbc.pool.OracleDataSource to create connections and 
   then cache them.
    
    Step 1: Enter the Database details in this file. 
            DB_USER, DB_PASSWORD and DB_URL are required
    Step 2: Run the sample with "ant DataSourceSample"
  
   NOTES
    Use JDK 1.7 and above

   MODIFIED    (MM/DD/YY)
    nbsundar    02/17/15 - Creation 
 */

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Properties;

import org.json.JSONException;

import oracle.jdbc.pool.OracleDataSource;
import oracle.jdbc.OracleConnection;
import java.sql.DatabaseMetaData;

public class DBCONNECTOR {
	final static String DB_URL = "jdbc:oracle:thin:@ora14.informatik.haw-hamburg.de:1521:inf14";
	final static String DB_USER = "acf040";
	final static String DB_PASSWORD = "Pa55wort";

	static OracleConnection oracleConnection = null;

	public void setup() throws SQLException {
		Properties info = new Properties();
		info.put(OracleConnection.CONNECTION_PROPERTY_USER_NAME, DB_USER);
		info.put(OracleConnection.CONNECTION_PROPERTY_PASSWORD, DB_PASSWORD);
		info.put(OracleConnection.CONNECTION_PROPERTY_DEFAULT_ROW_PREFETCH, "20");

		OracleDataSource ods = new OracleDataSource();
		ods.setURL(DB_URL);
		ods.setConnectionProperties(info);

		try {
			oracleConnection = (OracleConnection) ods.getConnection();
			DatabaseMetaData dbmd = oracleConnection.getMetaData();
			System.out.println("Driver Name: " + dbmd.getDriverName());
			System.out.println("Driver Version: " + dbmd.getDriverVersion());
			System.out.println("Default Row Prefetch Value is: " + oracleConnection.getDefaultRowPrefetch());
			System.out.println("Database Username is: " + oracleConnection.getUserName());
			System.out.println();
		} catch (Exception e) {
		}
	}

	public Artikel[] getArtikel() throws SQLException, IOException, JSONException {
		System.out.println("TRY GET ARTIKEL");
		
		ArrayList<Artikel> artikel = new ArrayList<Artikel>();
		
		try (Statement statement = oracleConnection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery("select * from ARTIKEL")) {

				while (resultSet.next()) {
					artikel.add(new Artikel(resultSet.getInt("ARTNR"), resultSet.getString("ARTNAME"),
							resultSet.getString("ARTGRP"), resultSet.getString("GRPNAME")));
				}
				

			}
		}
		return artikel.toArray(new Artikel[artikel.size()]);
	}

	public Kunden[] getKunden() throws SQLException, IOException, JSONException {
		System.out.println("TRY GET KUNDEN");
		
		ArrayList<Kunden> kunden = new ArrayList<Kunden>();
		
		try (Statement statement = oracleConnection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery("select * from KUNDEN")) {


				while (resultSet.next()) {
					kunden.add(new Kunden(resultSet.getInt("KUNDENNUMMER"), resultSet.getString("VORNAME"),
						resultSet.getString("NAME"), resultSet.getString("STRASSE"), resultSet.getString("PLZ"),
						resultSet.getString("WOHNORT")));
				}
			}
		}
		return kunden.toArray(new Kunden[kunden.size()]);
		
	}

	public Datum[] getDatum() throws SQLException, IOException, JSONException {
		System.out.println("TRY GET DATUM");
		
		ArrayList<Datum> dati = new ArrayList<Datum>();
		
		try (Statement statement = oracleConnection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery("select * from DATUM")) {

				while (resultSet.next()) {
					dati.add( new Datum(LocalDateTime.of(resultSet.getInt("JAHR"), resultSet.getInt("MONAT"),
						resultSet.getInt("TAG"), 0, 0), resultSet.getInt("JAHR"), resultSet.getInt("MONAT"),
						resultSet.getInt("TAG")));

				}
			}
		}
		
		return dati.toArray(new Datum[dati.size()]);
	}

	public Absatz[] getAbsatz() throws SQLException, IOException, JSONException {
		System.out.println("TRY GET ABSATZ");

		ArrayList<Absatz> absaetze = new ArrayList<Absatz>();
		
		try (Statement statement = oracleConnection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery("select * from ABSATZ")) {

				while (resultSet.next()) {
					
					String tag = resultSet.getString("DATUM").substring(0, 2);
					String monat = resultSet.getString("DATUM").substring(3, 5);
					String jahr = resultSet.getString("DATUM").substring(6, 8);
					String[] uhrzeitS = resultSet.getString("UHRZEIT").split(":");
					LocalDateTime datum = LocalDateTime.of(Integer.parseInt(jahr), Integer.parseInt(monat),
							Integer.parseInt(tag), Integer.parseInt(uhrzeitS[0]), Integer.parseInt(uhrzeitS[1]));
					
					absaetze.add(new Absatz(resultSet.getString("FILIALE"), datum, resultSet.getInt("ARTIKEL"),
							resultSet.getInt("ANZAHL"), resultSet.getDouble("PREIS"), resultSet.getDouble("UMSATZ"),
							resultSet.getString("VERKAEUFER"), resultSet.getInt("KUNDENNUMMER")));
				
				}
			}
			
		}
		
		Absatz[] absaetzeA = new Absatz[absaetze.size()];
		return absaetze.toArray(absaetzeA);
	}

	public Verkaeufer[] getVerkaeufer() throws SQLException, IOException, JSONException {
		System.out.println("TRY GET VERKAUFER");

		ArrayList<Verkaeufer> verkaufer = new ArrayList<Verkaeufer>();
		
		try (Statement statement = oracleConnection.createStatement()) {
			try (ResultSet resultSet = statement.executeQuery("select * from VERKAEUFER")) {

				while (resultSet.next()) {
					verkaufer.add(new Verkaeufer(resultSet.getString("NAME"), resultSet.getString("FILIALE"),
						resultSet.getDate("GEBURTSTAG"),
						resultSet.getString("WOHNORT")));
				
				}
			}
		}
		
		return verkaufer.toArray(new Verkaeufer[verkaufer.size()]);
	}

}
