package hello;

import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.sql.SQLException;

import org.json.JSONException;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
public class RouterController {

	@RequestMapping("/")
	public String index() {
		return "Greetings from Spring Boot!";
	}

	// Absatz

	@RequestMapping("/absatz")
	public Absatz[] absatz() throws SQLException, JSONException, IOException {
		return absatz2();
	}

	@RequestMapping("/Absatz")
	public Absatz[] absatz2() throws SQLException, JSONException, IOException {

			DBCONNECTOR dbc = new DBCONNECTOR();
			dbc.setup();
			return dbc.getAbsatz();

	}
	
	@RequestMapping("/artikel")
	public Artikel[] artikel() throws SQLException, JSONException, IOException {
		return artikel2();
	}
	
	@RequestMapping("/Artikel")
	public Artikel[] artikel2() throws SQLException, JSONException, IOException {

			DBCONNECTOR dbc = new DBCONNECTOR();
			dbc.setup();
			return dbc.getArtikel();

	}
	
	@RequestMapping("/kunden")
	public Kunden[] kunden() throws SQLException, JSONException, IOException {
		return kunden2();
	}
	
	@RequestMapping("/Kunden")
	public Kunden[] kunden2() throws SQLException, JSONException, IOException {

			DBCONNECTOR dbc = new DBCONNECTOR();
			dbc.setup();
			return dbc.getKunden();

	}
	
	@RequestMapping("/verkaeufer")
	public Verkaeufer[] verkaeufer() throws SQLException, JSONException, IOException {
		return verkaeufer2();
	}
	
	@RequestMapping("/Verkaeufer")
	public Verkaeufer[] verkaeufer2() throws SQLException, JSONException, IOException {

			DBCONNECTOR dbc = new DBCONNECTOR();
			dbc.setup();
			return dbc.getVerkaeufer();

	}
	
	@RequestMapping("/datum")
	public Datum[] datum() throws SQLException, JSONException, IOException {
		return datum2();
	}
	
	@RequestMapping("/Datum")
	public Datum[] datum2() throws SQLException, JSONException, IOException {

			DBCONNECTOR dbc = new DBCONNECTOR();
			dbc.setup();
			return dbc.getDatum();

	}

	

}
