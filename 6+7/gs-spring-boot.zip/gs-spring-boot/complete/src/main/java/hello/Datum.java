package hello;

import java.time.LocalDateTime;

public class Datum {

	LocalDateTime datum;
	int jahr;
	int monat;
	int tag;
	
	public LocalDateTime getDatum() {
		return datum;
	}
	public int getJahr() {
		return jahr;
	}
	public int getMonat() {
		return monat;
	}
	public int getTag() {
		return tag;
	}
	
	public Datum(LocalDateTime datum,int jahr,int monat,int tag) {
		
		this.datum = datum;
		this.jahr = jahr;
		this.monat = monat;
		this.tag = tag;
		
	}
	
}
