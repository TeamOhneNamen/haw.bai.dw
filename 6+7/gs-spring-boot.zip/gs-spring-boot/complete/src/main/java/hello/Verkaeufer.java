package hello;

import java.time.LocalDate;
import java.util.Date;

public class Verkaeufer {

	String name;
	String filiale;
	Date geburtstag;
	String wohnOrt;
	
	public String getName() {
		return name;
	}
	public String getFiliale() {
		return filiale;
	}
	public Date getGeburtstag() {
		return geburtstag;
	}
	public String getWohnOrt() {
		return wohnOrt;
	}
	
	public Verkaeufer(String name,String filiale,Date geburtstag,String wohnOrt) {
		
		this.name = name;
		this.filiale = filiale;
		this.geburtstag = geburtstag;
		this.wohnOrt = wohnOrt;
		
	}
	
}
